# Attribution

`@bl4ckh4nd/react-sherpa` is a fork of:

- Project: [`react-joyride`](https://github.com/gilbarbara/react-joyride)
- Original author: Gil Barbara
- License: MIT

This fork includes substantial architectural changes, including hook-based components, Floating UI integration, and store modernization.

This package is an independent fork and is not an official release from the original `react-joyride` maintainers.

The inherited Git history and contributor graph are retained for authorship and do not
indicate current React Sherpa maintainership.
