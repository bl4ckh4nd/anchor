# @bl4ckh4nd/react-sherpa

[![npm version](https://img.shields.io/npm/v/%40bl4ckh4nd%2Freact-sherpa)](https://www.npmjs.com/package/@bl4ckh4nd/react-sherpa)
[![CI](https://github.com/bl4ckh4nd/react-sherpa/actions/workflows/main.yml/badge.svg)](https://github.com/bl4ckh4nd/react-sherpa/actions/workflows/main.yml)

Independently maintained, modernized fork of `react-joyride`.

This package includes:
- Hook-based components (no class components)
- Floating UI positioning (no `react-floater`)
- Modernized internals and typing improvements

## Attribution

This project is a fork of [react-joyride](https://github.com/gilbarbara/react-joyride) by Gil Barbara and keeps the original MIT license.

This package is not an official release of `react-joyride`.

Inherited contributors remain in the Git history to preserve authorship; they are not
necessarily current React Sherpa maintainers.

See [ATTRIBUTION.md](./ATTRIBUTION.md) for details.

## Install

```bash
npm i @bl4ckh4nd/react-sherpa
```

## Usage

```jsx
import { useState } from 'react';
import Sherpa, { STATUS } from '@bl4ckh4nd/react-sherpa';

const steps = [
  { target: '.my-first-step', content: 'This is my awesome feature!' },
  { target: '.my-other-step', content: 'This is another awesome feature!' },
];

export default function App() {
  const [run, setRun] = useState(false);

  const handleJoyrideCallback = data => {
    if ([STATUS.FINISHED, STATUS.SKIPPED].includes(data.status)) {
      setRun(false);
    }
  };

  return (
    <div>
      <Sherpa callback={handleJoyrideCallback} run={run} showSkipButton steps={steps} />
      <button onClick={() => setRun(true)} type="button">
        Start
      </button>
    </div>
  );
}
```

## Docs

- Local docs: [`docs/`](./docs)
- Repository: https://github.com/bl4ckh4nd/react-sherpa
- Upstream project: https://github.com/gilbarbara/react-joyride
