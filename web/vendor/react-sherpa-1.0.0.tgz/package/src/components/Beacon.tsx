import { useEffect, useRef } from 'react';
import type { ElementType } from 'react';
import is from 'is-lite';

import { getBeaconAdapterProps } from '~/modules/adapters';

import { BeaconProps } from '~/types';

export default function JoyrideBeacon(props: BeaconProps) {
  const {
    beaconComponent,
    continuous,
    index,
    isLastStep,
    locale,
    nonce,
    onClickOrHover,
    shouldFocus,
    size,
    step,
    styles,
  } = props;
  const beaconRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (beaconComponent) {
      return undefined;
    }

    const head = document.head || document.getElementsByTagName('head')[0];
    const style = document.createElement('style');

    style.id = 'joyride-beacon-animation';

    if (nonce) {
      style.setAttribute('nonce', nonce);
    }

    const css = `
        @keyframes joyride-beacon-inner {
          20% {
            opacity: 0.9;
          }
        
          90% {
            opacity: 0.7;
          }
        }
        
        @keyframes joyride-beacon-outer {
          0% {
            transform: scale(1);
          }
        
          45% {
            opacity: 0.7;
            transform: scale(0.75);
          }
        
          100% {
            opacity: 0.9;
            transform: scale(1);
          }
        }
      `;

    style.appendChild(document.createTextNode(css));
    head.appendChild(style);

    return () => {
      const existingStyle = document.getElementById('joyride-beacon-animation');

      if (existingStyle?.parentNode) {
        existingStyle.parentNode.removeChild(existingStyle);
      }
    };
  }, [beaconComponent, nonce]);

  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') {
      if (!is.domElement(beaconRef.current)) {
        console.warn('beacon is not a valid DOM element'); // eslint-disable-line no-console
      }
    }

    const timeout = window.setTimeout(() => {
      if (is.domElement(beaconRef.current) && shouldFocus) {
        beaconRef.current.focus();
      }
    }, 0);

    return () => {
      clearTimeout(timeout);
    };
  }, [shouldFocus]);

  const beaconPayload = getBeaconAdapterProps({
    continuous,
    index,
    isLastStep,
    locale,
    onClickOrHover,
    setBeaconRef: (element: HTMLElement | null) => {
      beaconRef.current = element;
    },
    size,
    step,
  });

  if (beaconComponent) {
    const BeaconComponent = beaconComponent as ElementType;

    return <BeaconComponent {...beaconPayload} />;
  }

  const {
    continuous: _continuous,
    index: _index,
    isLastStep: _isLastStep,
    size: _size,
    step: _step,
    ...beaconProps
  } = beaconPayload;

  return (
    <button
      key="JoyrideBeacon"
      className="react-sherpa__beacon"
      data-test-id="button-beacon"
      style={styles.beacon}
      type="button"
      {...beaconProps}
    >
      <span style={styles.beaconInner} />
      <span style={styles.beaconOuter} />
    </button>
  );
}
