import { CSSProperties, MouseEvent, useEffect, useMemo, useRef, useState } from 'react';
import treeChanges from 'tree-changes';

import {
  getClientRect,
  getDocumentHeight,
  getElement,
  getElementPosition,
  getScrollParent,
  hasCustomScrollParent,
  hasPosition,
  prefersReducedMotion,
} from '~/modules/dom';
import { log } from '~/modules/helpers';

import { LIFECYCLE } from '~/literals';

import { Lifecycle, OverlayProps } from '~/types';

import Spotlight from './Spotlight';

interface SpotlightStyles extends CSSProperties {
  height: number;
  left: number;
  top: number;
  width: number;
}

interface State {
  isScrolling: boolean;
  mouseOverSpotlight: boolean;
  showSpotlight: boolean;
}

export default function JoyrideOverlay(props: OverlayProps) {
  const {
    continuous,
    debug,
    disableOverlay,
    disableOverlayClose,
    disableScrolling,
    disableScrollParentFix = false,
    lifecycle,
    onClickOverlay,
    placement,
    spotlightClicks,
    spotlightPadding = 0,
    styles,
    target,
  } = props;
  const [state, setState] = useState<State>({
    isScrolling: false,
    mouseOverSpotlight: false,
    showSpotlight: true,
  });
  const [, setRenderTick] = useState(0);
  const stateRef = useRef(state);
  const isActiveRef = useRef(false);
  const overlayElementRef = useRef<HTMLDivElement | null>(null);
  const resizeTimeoutRef = useRef<number | undefined>(undefined);
  const scrollTimeoutRef = useRef<number | undefined>(undefined);
  const scrollParentRef = useRef<Document | Element | undefined>(undefined);
  const previousPropsRef = useRef<OverlayProps>(props);
  const spotlightStylesRef = useRef<SpotlightStyles>({
    height: 0,
    left: 0,
    top: 0,
    width: 0,
  });

  stateRef.current = state;

  const updateState = (nextState: Partial<State>) => {
    if (!isActiveRef.current) {
      return;
    }

    setState(previousState => ({ ...previousState, ...nextState }));
  };

  const hideSpotlight = useMemo(() => {
    const hiddenLifecycles = [
      LIFECYCLE.INIT,
      LIFECYCLE.BEACON,
      LIFECYCLE.COMPLETE,
      LIFECYCLE.ERROR,
    ] as Lifecycle[];

    return (
      disableOverlay ||
      (continuous ? hiddenLifecycles.includes(lifecycle) : lifecycle !== LIFECYCLE.TOOLTIP)
    );
  }, [continuous, disableOverlay, lifecycle]);

  const overlayStyles = useMemo(() => {
    return {
      cursor: disableOverlayClose ? 'default' : 'pointer',
      height: getDocumentHeight(),
      pointerEvents: state.mouseOverSpotlight ? 'none' : 'auto',
      ...styles.overlay,
    } as CSSProperties;
  }, [disableOverlayClose, state.mouseOverSpotlight, styles.overlay]);

  const spotlightStyles = useMemo((): SpotlightStyles => {
    const element = getElement(target);
    const elementRect = getClientRect(element);
    const isFixedTarget = hasPosition(element);
    const top = getElementPosition(element, spotlightPadding, disableScrollParentFix);

    return {
      ...styles.spotlight,
      height: Math.round((elementRect?.height ?? 0) + spotlightPadding * 2),
      left: Math.round((elementRect?.left ?? 0) - spotlightPadding),
      opacity: state.showSpotlight ? 1 : 0,
      pointerEvents: spotlightClicks ? 'none' : 'auto',
      position: isFixedTarget ? 'fixed' : 'absolute',
      top,
      transition: prefersReducedMotion() ? 'none' : 'opacity 0.2s',
      width: Math.round((elementRect?.width ?? 0) + spotlightPadding * 2),
    } satisfies CSSProperties;
  }, [
    disableScrollParentFix,
    spotlightClicks,
    spotlightPadding,
    state.showSpotlight,
    styles.spotlight,
    target,
  ]);

  spotlightStylesRef.current = spotlightStyles;

  const isCursorInSpotlight = (x: number, y: number) => {
    const { height, left, top, width } = spotlightStyles;
    const inSpotlightHeight = y >= top && y <= top + height;
    const inSpotlightWidth = x >= left && x <= left + width;

    return inSpotlightHeight && inSpotlightWidth;
  };

  const handlePointerMove = (event: globalThis.MouseEvent | PointerEvent) => {
    const { mouseOverSpotlight } = stateRef.current;
    const { height, left, position, top, width } = spotlightStylesRef.current;
    const offsetY = position === 'fixed' ? event.clientY : event.pageY;
    const offsetX = position === 'fixed' ? event.clientX : event.pageX;
    const inSpotlightHeight = offsetY >= top && offsetY <= top + height;
    const inSpotlightWidth = offsetX >= left && offsetX <= left + width;
    const inSpotlight = inSpotlightWidth && inSpotlightHeight;

    if (inSpotlight !== mouseOverSpotlight) {
      updateState({ mouseOverSpotlight: inSpotlight });
    }
  };

  const handleScroll = () => {
    const element = getElement(target);
    const scrollParent = scrollParentRef.current;

    if (scrollParent !== document) {
      const { isScrolling } = stateRef.current;

      if (!isScrolling) {
        updateState({ isScrolling: true, showSpotlight: false });
      }

      clearTimeout(scrollTimeoutRef.current);

      scrollTimeoutRef.current = window.setTimeout(() => {
        updateState({ isScrolling: false, showSpotlight: true });
      }, 50);
    } else if (hasPosition(element, 'sticky')) {
      updateState({});
    }
  };

  const handleResize = () => {
    clearTimeout(resizeTimeoutRef.current);

    resizeTimeoutRef.current = window.setTimeout(() => {
      if (!isActiveRef.current) {
        return;
      }

      setRenderTick(previousValue => previousValue + 1);
    }, 100);
  };

  const handleClickOverlay = (event: MouseEvent<HTMLDivElement>) => {
    const hasPointerPosition = event.clientX !== 0 || event.clientY !== 0;

    if (spotlightClicks && hasPointerPosition && isCursorInSpotlight(event.pageX, event.pageY)) {
      if (overlayElementRef.current) {
        const currentPointerEvents = overlayElementRef.current.style.pointerEvents;

        overlayElementRef.current.style.pointerEvents = 'none';

        const clickTarget =
          typeof document.elementFromPoint === 'function'
            ? (document.elementFromPoint(event.clientX, event.clientY) as HTMLElement | null)
            : null;

        overlayElementRef.current.style.pointerEvents = currentPointerEvents;

        if (clickTarget && clickTarget !== overlayElementRef.current) {
          clickTarget.click();

          return;
        }
      }
    }

    onClickOverlay();
  };

  useEffect(() => {
    const element = getElement(target);

    scrollParentRef.current = getScrollParent(
      element ?? document.body,
      disableScrollParentFix,
      true,
    );
    isActiveRef.current = true;

    if (process.env.NODE_ENV !== 'production') {
      if (!disableScrolling && hasCustomScrollParent(element, true)) {
        log({
          title: 'step has a custom scroll parent and can cause trouble with scrolling',
          data: [{ key: 'parent', value: scrollParentRef.current }],
          debug,
        });
      }
    }

    window.addEventListener('resize', handleResize);

    return () => {
      isActiveRef.current = false;
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeoutRef.current);
      clearTimeout(scrollTimeoutRef.current);
      scrollParentRef.current?.removeEventListener('scroll', handleScroll);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const previousProps = previousPropsRef.current;
    const { changed } = treeChanges(previousProps, props);
    const element = getElement(target);

    if (changed('target') || changed('disableScrollParentFix')) {
      scrollParentRef.current = getScrollParent(
        element ?? document.body,
        disableScrollParentFix,
        true,
      );
    }

    previousPropsRef.current = props;

    if (changed('lifecycle', LIFECYCLE.TOOLTIP)) {
      scrollParentRef.current?.addEventListener('scroll', handleScroll, { passive: true });

      const timeout = window.setTimeout(() => {
        const { isScrolling } = stateRef.current;

        if (!isScrolling) {
          updateState({ showSpotlight: true });
        }
      }, 100);

      return () => {
        clearTimeout(timeout);
        scrollParentRef.current?.removeEventListener('scroll', handleScroll);
      };
    }

    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disableScrollParentFix, lifecycle, props, target]);

  useEffect(() => {
    if (spotlightClicks && lifecycle === LIFECYCLE.TOOLTIP) {
      window.addEventListener('pointermove', handlePointerMove, false);

      return () => {
        window.removeEventListener('pointermove', handlePointerMove);
      };
    }

    window.removeEventListener('pointermove', handlePointerMove);

    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lifecycle, spotlightClicks]);

  if (hideSpotlight) {
    return null;
  }

  const spotlight = placement !== 'center' && state.showSpotlight && (
    <Spotlight styles={spotlightStyles} />
  );

  return (
    <div
      ref={element => {
        overlayElementRef.current = element;
      }}
      className="react-sherpa__overlay"
      data-test-id="overlay"
      onClick={handleClickOverlay}
      role="presentation"
      style={overlayStyles}
    >
      {spotlight}
    </div>
  );
}
