import { ReactElement, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';

import { canUseDOM } from '~/modules/dom';

interface Props {
  children: ReactElement;
  id: string;
}

export default function JoyridePortal(props: Props) {
  const { children, id } = props;
  const [node, setNode] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (!canUseDOM()) {
      return undefined;
    }

    const element = document.createElement('div');

    element.id = id;
    document.body.appendChild(element);
    setNode(element);

    return () => {
      if (element.parentNode === document.body) {
        document.body.removeChild(element);
      }
    };
  }, [id]);

  if (!canUseDOM() || !node) {
    return null;
  }

  return createPortal(children, node);
}
