import { CSSProperties, MouseEvent, useEffect, useMemo, useRef } from 'react';
import {
  autoPlacement,
  autoUpdate,
  flip,
  FloatingPortal,
  offset,
  Placement as FloatingPlacement,
  shift,
  useFloating,
} from '@floating-ui/react';
import is from 'is-lite';
import treeChanges from 'tree-changes';

import { getElement, isElementVisible } from '~/modules/dom';
import { hideBeacon, log } from '~/modules/helpers';
import Scope from '~/modules/scope';
import { validateStep } from '~/modules/step';

import { ACTIONS, EVENTS, LIFECYCLE, STATUS } from '~/literals';

import { Placement, PositioningData, StepMerged, StepProps } from '~/types';

import Beacon from './Beacon';
import Tooltip from './Tooltip/index';

function getBasePlacement(placement: FloatingPlacement): Placement {
  return placement.split('-')[0] as Placement;
}

function isAutoPlacement(placement: StepMerged['placement']) {
  return placement === 'auto' || placement === 'auto-start' || placement === 'auto-end';
}

function toFloatingPlacement(placement: StepMerged['placement']): FloatingPlacement {
  if (placement === 'center' || isAutoPlacement(placement)) {
    return 'bottom';
  }

  return placement;
}

export default function JoyrideStep(props: StepProps) {
  const {
    action,
    callback,
    continuous,
    controlled,
    debug,
    helpers,
    index,
    lifecycle,
    nonce,
    shouldScroll,
    size,
    status,
    step,
    store,
  } = props;
  const previousPropsRef = useRef<StepProps | null>(null);
  const scopeRef = useRef<Scope | null>(null);
  const tooltipRef = useRef<HTMLElement | null>(null);
  const zIndex = (step.styles.options.zIndex ?? 100) + 100;

  const getDetectOverflowOptions = () => {
    if (step.positioning.boundary === 'viewport') {
      return { rootBoundary: 'viewport' as const };
    }

    if (step.positioning.boundary === 'clippingParents') {
      return { boundary: 'clippingAncestors' as const };
    }

    return { boundary: step.positioning.boundary };
  };

  const getMiddleware = (placement: StepMerged['placement']) => {
    const middleware = [offset(step.offset)];
    const detectOverflowOptions = getDetectOverflowOptions();

    if (isAutoPlacement(placement)) {
      let alignment: 'start' | 'end' | null = null;

      if (placement === 'auto-start') {
        alignment = 'start';
      } else if (placement === 'auto-end') {
        alignment = 'end';
      }

      middleware.push(
        autoPlacement({
          alignment,
          ...detectOverflowOptions,
        }),
      );
    } else {
      if (step.positioning.flip) {
        middleware.push(flip(detectOverflowOptions));
      }

      if (step.positioning.shift) {
        middleware.push(shift(detectOverflowOptions));
      }
    }

    return middleware;
  };

  const beaconPlacement = step.placementBeacon ?? step.placement;
  const beaconFloating = useFloating({
    middleware: getMiddleware(beaconPlacement),
    placement: toFloatingPlacement(beaconPlacement),
    strategy: step.positioning.strategy,
    whileElementsMounted: step.positioning.autoUpdate ? autoUpdate : undefined,
  });
  const tooltipFloating = useFloating({
    middleware: getMiddleware(step.placement),
    placement: toFloatingPlacement(step.placement),
    strategy: step.positioning.strategy,
    whileElementsMounted: step.positioning.autoUpdate ? autoUpdate : undefined,
  });

  const initScope = () => {
    if (!tooltipRef.current) {
      return;
    }

    scopeRef.current?.removeScope();
    scopeRef.current = new Scope(tooltipRef.current, { selector: '[data-action=primary]' });
    scopeRef.current.setFocus();
  };

  useEffect(() => {
    log({
      title: `step:${index}`,
      data: [{ key: 'props', value: props }],
      debug,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const previousProps = previousPropsRef.current;

    if (!previousProps) {
      previousPropsRef.current = props;

      return;
    }

    const { changed, changedFrom } = treeChanges(previousProps, props);
    const state = helpers.info();
    const skipBeacon =
      continuous && action !== ACTIONS.CLOSE && (index > 0 || action === ACTIONS.PREV);
    const hasStoreChanged =
      changed('action') || changed('index') || changed('lifecycle') || changed('status');
    const isInitial = changedFrom('lifecycle', [LIFECYCLE.TOOLTIP, LIFECYCLE.INIT], LIFECYCLE.INIT);
    const isAfterAction = changed('action', [
      ACTIONS.NEXT,
      ACTIONS.PREV,
      ACTIONS.SKIP,
      ACTIONS.CLOSE,
    ]);
    const isControlled = controlled && index === previousProps.index;

    if (isAfterAction && (isInitial || isControlled)) {
      callback({
        ...state,
        index: previousProps.index,
        lifecycle: LIFECYCLE.COMPLETE,
        step: previousProps.step,
        type: EVENTS.STEP_AFTER,
      });
    }

    if (
      step.placement === 'center' &&
      status === STATUS.RUNNING &&
      changed('index') &&
      action !== ACTIONS.START &&
      lifecycle === LIFECYCLE.INIT
    ) {
      store.update({ lifecycle: LIFECYCLE.READY });
    }

    if (hasStoreChanged) {
      const element = getElement(step.target);
      const elementExists = !!element;
      const hasRenderedTarget = elementExists && isElementVisible(element);

      if (hasRenderedTarget) {
        if (
          changedFrom('status', STATUS.READY, STATUS.RUNNING) ||
          changedFrom('lifecycle', LIFECYCLE.INIT, LIFECYCLE.READY)
        ) {
          callback({
            ...state,
            step,
            type: EVENTS.STEP_BEFORE,
          });
        }
      } else {
        // eslint-disable-next-line no-console
        console.warn(elementExists ? 'Target not visible' : 'Target not mounted', step);
        callback({
          ...state,
          type: EVENTS.TARGET_NOT_FOUND,
          step,
        });

        if (!controlled) {
          store.update({ index: index + (action === ACTIONS.PREV ? -1 : 1) });
        }
      }
    }

    if (changedFrom('lifecycle', LIFECYCLE.INIT, LIFECYCLE.READY)) {
      store.update({
        lifecycle: hideBeacon(step) || skipBeacon ? LIFECYCLE.TOOLTIP : LIFECYCLE.BEACON,
      });
    }

    if (changed('index')) {
      log({
        title: `step:${lifecycle}`,
        data: [{ key: 'props', value: props }],
        debug,
      });
    }

    if (changed('lifecycle', LIFECYCLE.BEACON)) {
      callback({
        ...state,
        step,
        type: EVENTS.BEACON,
      });
    }

    if (changed('lifecycle', LIFECYCLE.TOOLTIP)) {
      callback({
        ...state,
        step,
        type: EVENTS.TOOLTIP,
      });
      initScope();
    }

    if (changedFrom('lifecycle', [LIFECYCLE.TOOLTIP, LIFECYCLE.INIT], LIFECYCLE.INIT)) {
      scopeRef.current?.removeScope();
      store.cleanupPoppers();
    }

    previousPropsRef.current = props;
  });

  useEffect(() => {
    return () => {
      scopeRef.current?.removeScope();
    };
  }, []);

  const handleClickHoverBeacon = (event: MouseEvent<HTMLElement>) => {
    if (event.type === 'mouseenter' && step.event !== 'hover') {
      return;
    }

    store.update({ lifecycle: LIFECYCLE.TOOLTIP });
  };

  const setTooltipRef = (element: HTMLElement | null) => {
    tooltipRef.current = element;

    if (element && lifecycle === LIFECYCLE.TOOLTIP) {
      initScope();
    }
  };

  const getPositioningData = (
    placement: FloatingPlacement,
    x: number | null,
    y: number | null,
    update: () => Promise<void> | void,
  ): PositioningData => {
    return {
      state: {
        modifiersData: {
          popperOffsets: is.number(x) && is.number(y) ? { x, y } : undefined,
        },
        placement: getBasePlacement(placement),
      },
      update,
    };
  };

  const open = useMemo(() => {
    return hideBeacon(step) || lifecycle === LIFECYCLE.TOOLTIP;
  }, [lifecycle, step]);

  const target = getElement(step.target);

  useEffect(() => {
    if (!target) {
      return;
    }

    beaconFloating.refs.setReference(target);
    tooltipFloating.refs.setReference(target);
  }, [beaconFloating.refs, target, tooltipFloating.refs]);

  useEffect(() => {
    if (step.placement === 'center') {
      return;
    }

    store.setPopper(
      'beacon',
      getPositioningData(
        beaconFloating.placement,
        beaconFloating.x,
        beaconFloating.y,
        beaconFloating.update,
      ),
    );
  }, [
    beaconFloating.placement,
    beaconFloating.update,
    beaconFloating.x,
    beaconFloating.y,
    step.placement,
    store,
  ]);

  useEffect(() => {
    store.setPopper(
      'tooltip',
      getPositioningData(
        tooltipFloating.placement,
        tooltipFloating.x,
        tooltipFloating.y,
        tooltipFloating.update,
      ),
    );
  }, [
    store,
    tooltipFloating.placement,
    tooltipFloating.update,
    tooltipFloating.x,
    tooltipFloating.y,
  ]);

  useEffect(() => {
    if (lifecycle !== LIFECYCLE.INIT) {
      return undefined;
    }

    const timeout = window.setTimeout(() => {
      store.update({
        action,
        lifecycle: LIFECYCLE.READY,
      });
    }, 0);

    return () => {
      clearTimeout(timeout);
    };
  }, [action, lifecycle, store]);

  if (!validateStep(step) || !is.domElement(target)) {
    return null;
  }

  const renderTooltip = () => (
    <Tooltip
      continuous={continuous}
      helpers={helpers}
      index={index}
      isLastStep={index + 1 === size}
      setTooltipRef={setTooltipRef}
      size={size}
      step={step}
    />
  );

  const beaconStyles: CSSProperties = {
    cursor: step.event === 'hover' ? 'pointer' : 'help',
    left: beaconFloating.x ?? 0,
    margin: 0,
    position: step.positioning.strategy,
    top: beaconFloating.y ?? 0,
    zIndex,
  };
  const tooltipStyles: CSSProperties =
    step.placement === 'center'
      ? {
          left: '50%',
          position: 'fixed',
          top: '50%',
          transform: 'translate(-50%, -50%)',
          zIndex,
        }
      : {
          left: tooltipFloating.x ?? 0,
          position: step.positioning.strategy,
          top: tooltipFloating.y ?? 0,
          zIndex,
        };

  return (
    <div key={`JoyrideStep-${index}`} className="react-sherpa__step">
      {step.placement !== 'center' && (
        <span
          ref={beaconFloating.refs.setFloating}
          id={`react-sherpa-step-${index}-wrapper`}
          style={beaconStyles}
        >
          <Beacon
            beaconComponent={step.beaconComponent}
            continuous={continuous}
            index={index}
            isLastStep={index + 1 === size}
            locale={step.locale}
            nonce={nonce}
            onClickOrHover={handleClickHoverBeacon}
            shouldFocus={shouldScroll}
            size={size}
            step={step}
            styles={step.styles}
          />
        </span>
      )}
      {open && (
        <FloatingPortal>
          <div
            ref={element => {
              tooltipFloating.refs.setFloating(element);
              setTooltipRef(element);
            }}
            id={`react-sherpa-step-${index}`}
            role="tooltip"
            style={tooltipStyles}
          >
            {renderTooltip()}
          </div>
        </FloatingPortal>
      )}
    </div>
  );
}
