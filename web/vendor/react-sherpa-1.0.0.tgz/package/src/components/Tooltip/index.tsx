import { MouseEvent } from 'react';

import { getTooltipAdapterProps } from '~/modules/adapters';

import { TooltipProps } from '~/types';

import Container from './Container';

export default function JoyrideTooltip(props: TooltipProps) {
  const handleClickBack = (event: MouseEvent<HTMLElement>) => {
    event.preventDefault();
    const { helpers } = props;

    helpers.prev();
  };

  const handleClickClose = (event: MouseEvent<HTMLElement>) => {
    event.preventDefault();
    const { helpers } = props;

    helpers.close('button_close');
  };

  const handleClickPrimary = (event: MouseEvent<HTMLElement>) => {
    event.preventDefault();
    const { continuous, helpers } = props;

    if (!continuous) {
      helpers.close('button_primary');

      return;
    }

    helpers.next();
  };

  const handleClickSkip = (event: MouseEvent<HTMLElement>) => {
    event.preventDefault();
    const { helpers } = props;

    helpers.skip();
  };

  const { continuous, index, isLastStep, setTooltipRef, size, step } = props;
  const { tooltipComponent } = step;
  const tooltipPayload = getTooltipAdapterProps({
    continuous,
    handlers: {
      back: handleClickBack,
      close: handleClickClose,
      primary: handleClickPrimary,
      skip: handleClickSkip,
    },
    index,
    isLastStep,
    setTooltipRef,
    size,
    step,
  });

  if (tooltipComponent) {
    const TooltipComponent = tooltipComponent;

    return <TooltipComponent {...tooltipPayload} />;
  }

  return (
    <Container
      {...tooltipPayload}
      continuous={continuous}
      index={index}
      isLastStep={isLastStep}
      size={size}
      step={step}
    />
  );
}
