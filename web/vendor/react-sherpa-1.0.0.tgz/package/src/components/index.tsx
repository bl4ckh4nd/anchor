import {
  forwardRef,
  ReactNode,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import isEqual from '@gilbarbara/deep-equal';
import is from 'is-lite';
import treeChanges from 'tree-changes';

import {
  canUseDOM,
  getElement,
  getScrollParent,
  getScrollTo,
  hasCustomScrollParent,
  scrollTo,
} from '~/modules/dom';
import { log, shouldScroll } from '~/modules/helpers';
import { getMergedStep, validateSteps } from '~/modules/step';
import createStore from '~/modules/store';

import { ACTIONS, EVENTS, LIFECYCLE, STATUS } from '~/literals';

import Overlay from '~/components/Overlay';
import Portal from '~/components/Portal';

import { defaultProps } from '~/defaults';
import { Actions, CallBackProps, Props, State, Status, StoreHelpers } from '~/types';

import Step from './Step';

const Joyride = forwardRef<StoreHelpers, Props>(function Joyride(props, ref) {
  const { getHelpers } = props;
  const storeRef = useRef<ReturnType<typeof createStore> | null>(null);
  const helpersRef = useRef<StoreHelpers | null>(null);
  const initialGetHelpersRef = useRef(getHelpers);
  const initialFocusedElementRef = useRef<HTMLElement | null>(null);
  const hasInitialFocusSnapshotRef = useRef(false);
  const previousPropsRef = useRef<Props | null>(null);
  const previousStateRef = useRef<State | null>(null);
  const propsRef = useRef(props);

  if (!storeRef.current) {
    const { run = true, stepIndex } = props;

    storeRef.current = createStore({
      ...props,
      controlled: run && is.number(stepIndex),
    });
  }

  const store = storeRef.current;

  if (!helpersRef.current) {
    helpersRef.current = store.getHelpers();
  }

  const helpers = helpersRef.current;
  const [state, setState] = useState<State>(() => store.getState());
  const stateRef = useRef(state);

  propsRef.current = props;
  stateRef.current = state;

  const captureInitialFocus = useCallback(() => {
    if (!canUseDOM() || hasInitialFocusSnapshotRef.current) {
      return;
    }

    const { activeElement } = document;

    if (activeElement instanceof HTMLElement && activeElement !== document.body) {
      initialFocusedElementRef.current = activeElement;
      hasInitialFocusSnapshotRef.current = true;
    }
  }, []);

  const restoreInitialFocus = useCallback(() => {
    if (!canUseDOM() || !hasInitialFocusSnapshotRef.current) {
      return;
    }

    if (
      initialFocusedElementRef.current &&
      document.contains(initialFocusedElementRef.current) &&
      !initialFocusedElementRef.current.hasAttribute('disabled')
    ) {
      initialFocusedElementRef.current.focus();
    }

    initialFocusedElementRef.current = null;
    hasInitialFocusSnapshotRef.current = false;
  }, []);

  const triggerCallback = useCallback((data: CallBackProps) => {
    const { callback } = propsRef.current;

    if (is.function(callback)) {
      callback(data);
    }
  }, []);

  const handleKeyboard = useCallback(
    (event: KeyboardEvent) => {
      const { index, lifecycle } = stateRef.current;
      const { steps } = propsRef.current;
      const step = steps[index];

      if (lifecycle === LIFECYCLE.TOOLTIP) {
        if (event.code === 'Escape' && step && !step.disableCloseOnEsc) {
          store.close('keyboard');
        }
      }
    },
    [store],
  );

  const handleClickOverlay = useCallback(() => {
    const currentProps = propsRef.current;
    const { index } = stateRef.current;
    const step = getMergedStep(currentProps, currentProps.steps[index]);

    if (!step.disableOverlayClose) {
      helpers.close('overlay');
    }
  }, [helpers]);

  const syncState = useCallback((nextState: State) => {
    setState(nextState);
  }, []);

  useEffect(() => {
    log({
      title: 'init',
      data: [
        { key: 'props', value: propsRef.current },
        { key: 'state', value: stateRef.current },
      ],
      debug: propsRef.current.debug,
    });
  }, []);

  useEffect(() => {
    store.addListener(syncState);
  }, [store, syncState]);

  useEffect(() => {
    initialGetHelpersRef.current?.(helpers);
  }, [helpers]);

  useImperativeHandle(ref, () => helpers, [helpers]);

  useEffect(() => {
    if (!canUseDOM()) {
      return undefined;
    }

    const { debug, disableCloseOnEsc, run, steps } = propsRef.current;

    if (validateSteps(steps, debug) && run) {
      captureInitialFocus();
      store.start();
    }

    if (!disableCloseOnEsc) {
      document.body.addEventListener('keydown', handleKeyboard, { passive: true });
    }

    return () => {
      document.body.removeEventListener('keydown', handleKeyboard);
      restoreInitialFocus();
    };
  }, [captureInitialFocus, handleKeyboard, restoreInitialFocus, store]);

  useEffect(() => {
    if (!canUseDOM()) {
      previousPropsRef.current = props;
      previousStateRef.current = state;

      return;
    }

    const previousProps = previousPropsRef.current;
    const previousState = previousStateRef.current;

    if (!previousProps || !previousState) {
      previousPropsRef.current = props;
      previousStateRef.current = state;

      return;
    }

    const { action, controlled, index, status } = state;
    const { debug, run, stepIndex, steps } = props;
    const { stepIndex: previousStepIndex, steps: previousSteps } = previousProps;
    const { changed: changedProps } = treeChanges(previousProps, props);
    const { changed, changedFrom } = treeChanges(previousState, state);
    const step = getMergedStep(props, steps[index]);

    const stepsChanged = !isEqual(previousSteps, steps);
    const stepIndexChanged = is.number(stepIndex) && changedProps('stepIndex');
    const target = getElement(step.target);

    if (stepsChanged) {
      if (validateSteps(steps, debug)) {
        store.setSteps(steps);
      } else {
        // eslint-disable-next-line no-console
        console.warn('Steps are not valid', steps);
      }
    }

    if (changedProps('run')) {
      if (run) {
        captureInitialFocus();
        store.start(stepIndex);
      } else {
        store.stop();
      }
    }

    if (stepIndexChanged) {
      let nextAction: Actions =
        is.number(previousStepIndex) && previousStepIndex < stepIndex ? ACTIONS.NEXT : ACTIONS.PREV;

      if (action === ACTIONS.STOP) {
        nextAction = ACTIONS.START;
      }

      if (!([STATUS.FINISHED, STATUS.SKIPPED] as Array<Status>).includes(status)) {
        store.update({
          action: action === ACTIONS.CLOSE ? ACTIONS.CLOSE : nextAction,
          index: stepIndex,
          lifecycle: LIFECYCLE.INIT,
        });
      }
    }

    // Update the index if the first step is not found
    if (!controlled && status === STATUS.RUNNING && index === 0 && !target) {
      store.update({ index: index + 1 });
      triggerCallback({
        ...state,
        type: EVENTS.TARGET_NOT_FOUND,
        step,
      });
    }

    const callbackData = {
      ...state,
      index,
      step,
    };
    const isAfterAction = changed('action', [
      ACTIONS.NEXT,
      ACTIONS.PREV,
      ACTIONS.SKIP,
      ACTIONS.CLOSE,
    ]);

    if (isAfterAction && changed('status', STATUS.PAUSED)) {
      const previousStep = getMergedStep(props, steps[previousState.index]);

      triggerCallback({
        ...callbackData,
        index: previousState.index,
        lifecycle: LIFECYCLE.COMPLETE,
        step: previousStep,
        type: EVENTS.STEP_AFTER,
      });
    }

    if (changed('status', [STATUS.FINISHED, STATUS.SKIPPED])) {
      const previousStep = getMergedStep(props, steps[previousState.index]);

      if (!controlled) {
        triggerCallback({
          ...callbackData,
          index: previousState.index,
          lifecycle: LIFECYCLE.COMPLETE,
          step: previousStep,
          type: EVENTS.STEP_AFTER,
        });
      }

      triggerCallback({
        ...callbackData,
        type: EVENTS.TOUR_END,
        // Return the last step when the tour is finished
        step: previousStep,
        index: previousState.index,
      });
      restoreInitialFocus();
      store.reset();
    } else if (changedFrom('status', [STATUS.IDLE, STATUS.READY], STATUS.RUNNING)) {
      captureInitialFocus();
      triggerCallback({
        ...callbackData,
        type: EVENTS.TOUR_START,
      });
    } else {
      if (changed('status', STATUS.PAUSED)) {
        restoreInitialFocus();
      }

      if (changed('status') || changed('action', ACTIONS.RESET)) {
        triggerCallback({
          ...callbackData,
          type: EVENTS.TOUR_STATUS,
        });
      }
    }

    const { lifecycle } = state;
    const {
      disableScrollParentFix = false,
      scrollDuration,
      scrollOffset = 20,
      scrollToFirstStep = false,
    } = props;
    const shouldScrollToStep = shouldScroll({
      isFirstStep: index === 0,
      lifecycle,
      previousLifecycle: previousState.lifecycle,
      scrollToFirstStep,
      step,
      target,
    });

    if (status === STATUS.RUNNING && shouldScrollToStep) {
      const hasCustomScroll = hasCustomScrollParent(target, disableScrollParentFix);
      const scrollParent = getScrollParent(target, disableScrollParentFix);
      let scrollY = Math.floor(getScrollTo(target, scrollOffset, disableScrollParentFix)) || 0;

      log({
        title: 'scrollToStep',
        data: [
          { key: 'index', value: index },
          { key: 'lifecycle', value: lifecycle },
          { key: 'status', value: status },
        ],
        debug,
      });

      const beaconPopper = store.getPopper('beacon');
      const tooltipPopper = store.getPopper('tooltip');

      if (lifecycle === LIFECYCLE.BEACON && beaconPopper) {
        const popperPlacement = beaconPopper.state.placement.split('-')[0];
        const popperOffsetY = beaconPopper.state.modifiersData.popperOffsets?.y;

        if (!['bottom'].includes(popperPlacement) && !hasCustomScroll && is.number(popperOffsetY)) {
          scrollY = Math.floor(popperOffsetY - scrollOffset);
        }
      } else if (lifecycle === LIFECYCLE.TOOLTIP && tooltipPopper) {
        const popperPlacement = tooltipPopper.state.placement.split('-')[0];
        const popperOffsetY = tooltipPopper.state.modifiersData.popperOffsets?.y;

        if (
          ['left', 'right', 'top'].includes(popperPlacement) &&
          !hasCustomScroll &&
          is.number(popperOffsetY)
        ) {
          scrollY = Math.floor(popperOffsetY - scrollOffset);
        } else {
          scrollY -= step.spotlightPadding;
        }
      }

      scrollY = scrollY >= 0 ? scrollY : 0;

      if (status === STATUS.RUNNING) {
        scrollTo(scrollY, { element: scrollParent as Element, duration: scrollDuration }).then(
          () => {
            setTimeout(() => {
              store.getPopper('tooltip')?.update();
            }, 10);
          },
        );
      }
    }

    previousPropsRef.current = props;
    previousStateRef.current = state;
  }, [captureInitialFocus, props, restoreInitialFocus, state, store, triggerCallback]);

  if (!canUseDOM()) {
    return null;
  }

  const { index, lifecycle, status } = state;
  const { continuous = false, debug = false, nonce, scrollToFirstStep = false, steps } = props;
  const isRunning = status === STATUS.RUNNING;
  const content: Record<string, ReactNode> = {};

  if (isRunning && steps[index]) {
    const step = getMergedStep(props, steps[index]);

    content.step = (
      <Step
        {...state}
        callback={triggerCallback}
        continuous={continuous}
        debug={debug}
        helpers={helpers}
        nonce={nonce}
        shouldScroll={!step.disableScrolling && (index !== 0 || scrollToFirstStep)}
        step={step}
        store={store}
      />
    );

    content.overlay = (
      <Portal id="react-sherpa-portal">
        <Overlay
          {...step}
          continuous={continuous}
          debug={debug}
          lifecycle={lifecycle}
          onClickOverlay={handleClickOverlay}
        />
      </Portal>
    );
  }

  return (
    <div className="react-sherpa">
      {content.step}
      {content.overlay}
    </div>
  );
});

// React 19 drops `defaultProps` from the forwardRef component type (and ignores it
// at runtime), so we assign through a typed cast to preserve the React 18 default-prop
// behavior without breaking the declaration build.
(Joyride as unknown as { defaultProps: Partial<Props> }).defaultProps = defaultProps;

export default Joyride;
