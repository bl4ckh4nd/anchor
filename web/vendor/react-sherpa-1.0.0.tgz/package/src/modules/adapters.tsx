import type { MouseEventHandler, ReactNode, RefCallback } from 'react';

import type { Locale } from '~/types';
import type {
  BeaconRenderProps,
  StepMerged,
  TooltipActionRenderProps,
  TooltipRenderProps,
} from '~/types/components';

import { getReactNodeText, replaceLocaleContent } from './helpers';

interface BeaconPayloadOptions {
  continuous: boolean;
  index: number;
  isLastStep: boolean;
  locale: Locale;
  onClickOrHover: MouseEventHandler<HTMLElement>;
  setBeaconRef: RefCallback<HTMLElement>;
  size: number;
  step: StepMerged;
}

interface TooltipPayloadOptions {
  continuous: boolean;
  handlers: {
    back: MouseEventHandler<HTMLElement>;
    close: MouseEventHandler<HTMLElement>;
    primary: MouseEventHandler<HTMLElement>;
    skip: MouseEventHandler<HTMLElement>;
  };
  index: number;
  isLastStep: boolean;
  setTooltipRef: RefCallback<HTMLElement>;
  size: number;
  step: StepMerged;
}

function getActionProps(
  action: string,
  children: ReactNode,
  onClick: MouseEventHandler<HTMLElement>,
  title: string,
): TooltipActionRenderProps {
  return {
    'aria-label': title,
    children,
    'data-action': action,
    onClick,
    role: 'button',
    title,
  };
}

export function getBeaconAdapterProps(options: BeaconPayloadOptions): BeaconRenderProps {
  const { continuous, index, isLastStep, locale, onClickOrHover, setBeaconRef, size, step } =
    options;
  const title = getReactNodeText(locale.open);

  return {
    'aria-label': title,
    continuous,
    index,
    isLastStep,
    onClick: onClickOrHover,
    onMouseEnter: onClickOrHover,
    ref: setBeaconRef,
    size,
    step,
    title,
  };
}

export function getTooltipAdapterProps(options: TooltipPayloadOptions): TooltipRenderProps {
  const { continuous, handlers, index, isLastStep, setTooltipRef, size, step } = options;
  const { back, close, last, next, nextLabelWithProgress, skip } = step.locale;
  const titleId = step.title ? `react-sherpa-step-title-${index}` : undefined;
  const contentId = step.content ? `react-sherpa-step-content-${index}` : undefined;

  const backText = getReactNodeText(back);
  const closeText = getReactNodeText(close);
  const lastText = getReactNodeText(last);
  const nextText = getReactNodeText(next);
  const skipText = getReactNodeText(skip);
  const labelText = getReactNodeText(step.title ?? step.content);

  let primary = close;
  let primaryText = closeText;

  if (continuous) {
    primary = next;
    primaryText = nextText;

    if (step.showProgress && !isLastStep) {
      primary = replaceLocaleContent(nextLabelWithProgress, index + 1, size);
      primaryText = getReactNodeText(nextLabelWithProgress, {
        step: index + 1,
        steps: size,
      });
    }

    if (isLastStep) {
      primary = last;
      primaryText = lastText;
    }
  }

  const { beaconComponent, tooltipComponent, ...cleanStep } = step;

  return {
    backProps: getActionProps('back', back, handlers.back, backText),
    closeProps: getActionProps('close', close, handlers.close, closeText),
    continuous,
    index,
    isLastStep,
    primaryProps: getActionProps('primary', primary, handlers.primary, primaryText),
    setTooltipRef,
    size,
    skipProps: getActionProps('skip', skip, handlers.skip, skipText),
    step: cleanStep,
    tooltipProps: {
      'aria-describedby': contentId,
      'aria-label': labelText,
      'aria-labelledby': titleId,
      'aria-modal': true,
      ref: setTooltipRef,
      role: 'alertdialog',
    },
  };
}
