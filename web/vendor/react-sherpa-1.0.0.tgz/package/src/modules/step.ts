import deepmerge from 'deepmerge';
import is from 'is-lite';

import { defaultLocale, defaultPositioning, defaultStep } from '~/defaults';
import getStyles from '~/styles';
import { Positioning, Props, Step, StepMerged } from '~/types';

import { getElement, hasCustomScrollParent } from './dom';
import { log, pick } from './helpers';

function getTourProps(props: Props) {
  return pick(
    props,
    'beaconComponent',
    'disableCloseOnEsc',
    'disableOverlay',
    'disableOverlayClose',
    'disableScrolling',
    'disableScrollParentFix',
    'hideBackButton',
    'hideCloseButton',
    'locale',
    'positioning',
    'showProgress',
    'showSkipButton',
    'spotlightClicks',
    'spotlightPadding',
    'styles',
    'tooltipComponent',
  );
}

export function getMergedStep(props: Props, currentStep?: Step): StepMerged {
  const step = currentStep ?? {};
  const mergedStep = deepmerge.all([defaultStep, getTourProps(props), step], {
    isMergeableObject: is.plainObject,
  }) as StepMerged;

  const mergedStyles = getStyles(props, mergedStep);
  const scrollParent = hasCustomScrollParent(
    getElement(mergedStep.target),
    mergedStep.disableScrollParentFix,
  );
  const positioning = deepmerge.all([
    defaultPositioning,
    props.positioning ?? {},
    mergedStep.positioning ?? {},
  ]) as Positioning;

  if (scrollParent && positioning.boundary === 'clippingParents') {
    positioning.boundary = 'viewport';
  }

  return {
    ...mergedStep,
    locale: deepmerge.all([defaultLocale, props.locale ?? {}, mergedStep.locale || {}]),
    positioning,
    styles: mergedStyles,
  };
}

/**
 * Validate if a step is valid
 */
export function validateStep(step: unknown, debug: boolean = false): boolean {
  if (!is.plainObject(step)) {
    log({
      title: 'validateStep',
      data: 'step must be an object',
      warn: true,
      debug,
    });

    return false;
  }

  const currentStep = step as Partial<Step>;

  if (!currentStep.target) {
    log({
      title: 'validateStep',
      data: 'target is missing from the step',
      warn: true,
      debug,
    });

    return false;
  }

  return true;
}

/**
 * Validate if steps are valid
 */
export function validateSteps(steps: unknown, debug: boolean = false): boolean {
  if (!is.array(steps)) {
    log({
      title: 'validateSteps',
      data: 'steps must be an array',
      warn: true,
      debug,
    });

    return false;
  }

  return steps.every(d => validateStep(d, debug));
}
