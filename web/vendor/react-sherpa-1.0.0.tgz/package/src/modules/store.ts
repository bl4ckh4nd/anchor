import isEqual from '@gilbarbara/deep-equal';
import is from 'is-lite';
import { createStore as createZustandStore } from 'zustand/vanilla';

import { ACTIONS, LIFECYCLE, STATUS } from '~/literals';

import { Origin, PositioningData, State, Status, Step, StoreHelpers, StoreOptions } from '~/types';

import { hasValidKeys, objectKeys, omit } from './helpers';

type InternalState = {
  action: State['action'];
  beaconPopper: PositioningData | null;
  continuous: boolean;
  controlled: boolean;
  index: number;
  lifecycle: State['lifecycle'];
  origin: State['origin'];
  size: number;
  status: State['status'];
  steps: Array<Step>;
  tooltipPopper: PositioningData | null;
};
type Listener = (state: State) => void;
type StateWithContinuous = State & { continuous: boolean };

const defaultState: State = {
  action: 'init',
  controlled: false,
  index: 0,
  lifecycle: LIFECYCLE.INIT,
  origin: null,
  size: 0,
  status: STATUS.IDLE,
};
const validKeys = objectKeys(omit(defaultState, 'controlled', 'size'));

export type StoreInstance = ReturnType<typeof createStore>;

class Store {
  private listener: Listener | null;
  private store = createZustandStore<InternalState>(() => ({
    action: ACTIONS.INIT,
    beaconPopper: null,
    continuous: false,
    controlled: false,
    index: 0,
    lifecycle: LIFECYCLE.INIT,
    origin: null,
    size: 0,
    status: STATUS.IDLE,
    steps: [],
    tooltipPopper: null,
  }));

  constructor(options?: StoreOptions) {
    const { continuous = false, stepIndex, steps = [] } = options ?? {};

    this.listener = null;
    this.setState(
      {
        action: ACTIONS.INIT,
        controlled: is.number(stepIndex),
        continuous,
        index: is.number(stepIndex) ? stepIndex : 0,
        lifecycle: LIFECYCLE.INIT,
        origin: null,
        status: steps.length ? STATUS.READY : STATUS.IDLE,
      },
      true,
    );
    this.setSteps(steps);
  }

  public getState(): State {
    const state = this.store.getState();

    return {
      action: state.action || '',
      controlled: state.controlled || false,
      index: state.index || 0,
      lifecycle: state.lifecycle || '',
      origin: state.origin || null,
      size: state.size || 0,
      status: (state.status as Status) || '',
    };
  }

  private getNextState(state: Partial<State>, force: boolean = false): State {
    const { action, controlled, index, size, status } = this.getState();
    const newIndex = is.number(state.index) ? state.index : index;
    const nextIndex = controlled && !force ? index : Math.min(Math.max(newIndex, 0), size);

    return {
      action: state.action ?? action,
      controlled,
      index: nextIndex,
      lifecycle: state.lifecycle ?? LIFECYCLE.INIT,
      origin: state.origin ?? null,
      size: state.size ?? size,
      status: nextIndex === size ? STATUS.FINISHED : state.status ?? status,
    };
  }

  private getSteps(): Array<Step> {
    return this.store.getState().steps;
  }

  private setState(nextState: Partial<StateWithContinuous>, initial: boolean = false) {
    const previousState = this.getState();
    const currentState = this.store.getState();
    const {
      action,
      index,
      lifecycle,
      origin = null,
      size,
      status,
    } = {
      ...previousState,
      ...nextState,
    };

    this.store.setState({
      ...currentState,
      action,
      controlled: initial ? Boolean(nextState.controlled) : currentState.controlled,
      continuous: initial ? Boolean(nextState.continuous) : currentState.continuous,
      index,
      lifecycle,
      origin,
      size,
      status,
    });

    if (this.listener && !isEqual(previousState, this.getState())) {
      this.listener(this.getState());
    }
  }

  public addListener = (listener: Listener) => {
    this.listener = listener;
  };

  public setSteps = (steps: Array<Step>) => {
    const { size, status } = this.getState();
    const nextStatus = status === STATUS.WAITING && !size && steps.length ? STATUS.RUNNING : status;

    this.store.setState({
      ...this.store.getState(),
      steps,
    });

    this.setState({
      size: steps.length,
      status: nextStatus,
    });
  };

  public getHelpers(): StoreHelpers {
    return {
      close: this.close,
      go: this.go,
      info: this.info,
      next: this.next,
      open: this.open,
      prev: this.prev,
      reset: this.reset,
      skip: this.skip,
    };
  }

  public getPopper = (name: 'beacon' | 'tooltip'): PositioningData | null => {
    const state = this.store.getState();

    return name === 'beacon' ? state.beaconPopper : state.tooltipPopper;
  };

  public setPopper = (name: 'beacon' | 'tooltip', popper: PositioningData) => {
    const state = this.store.getState();

    this.store.setState({
      ...state,
      beaconPopper: name === 'beacon' ? popper : state.beaconPopper,
      tooltipPopper: name === 'tooltip' ? popper : state.tooltipPopper,
    });
  };

  public cleanupPoppers = () => {
    this.store.setState({
      ...this.store.getState(),
      beaconPopper: null,
      tooltipPopper: null,
    });
  };

  public close = (origin: Origin | null = null) => {
    const { index, status } = this.getState();

    if (status !== STATUS.RUNNING) {
      return;
    }

    this.setState({
      ...this.getNextState({ action: ACTIONS.CLOSE, index: index + 1, origin }),
    });
  };

  public go = (nextIndex: number) => {
    const { controlled, status } = this.getState();

    if (controlled || status !== STATUS.RUNNING) {
      return;
    }

    const step = this.getSteps()[nextIndex];

    this.setState({
      ...this.getNextState({ action: ACTIONS.GO, index: nextIndex }),
      status: step ? status : STATUS.FINISHED,
    });
  };

  public info = (): State => this.getState();

  public next = () => {
    const { index, status } = this.getState();

    if (status !== STATUS.RUNNING) {
      return;
    }

    this.setState(this.getNextState({ action: ACTIONS.NEXT, index: index + 1 }));
  };

  public open = () => {
    const { status } = this.getState();

    if (status !== STATUS.RUNNING) {
      return;
    }

    this.setState({
      ...this.getNextState({ action: ACTIONS.UPDATE, lifecycle: LIFECYCLE.TOOLTIP }),
    });
  };

  public prev = () => {
    const { index, status } = this.getState();

    if (status !== STATUS.RUNNING) {
      return;
    }

    this.setState({
      ...this.getNextState({ action: ACTIONS.PREV, index: index - 1 }),
    });
  };

  public reset = (restart = false) => {
    const { controlled } = this.getState();

    if (controlled) {
      return;
    }

    this.setState({
      ...this.getNextState({ action: ACTIONS.RESET, index: 0 }),
      status: restart ? STATUS.RUNNING : STATUS.READY,
    });
  };

  public skip = () => {
    const { status } = this.getState();

    if (status !== STATUS.RUNNING) {
      return;
    }

    this.setState({
      action: ACTIONS.SKIP,
      lifecycle: LIFECYCLE.INIT,
      status: STATUS.SKIPPED,
    });
  };

  public start = (nextIndex?: number) => {
    const { index, size } = this.getState();

    this.setState({
      ...this.getNextState(
        {
          action: ACTIONS.START,
          index: is.number(nextIndex) ? nextIndex : index,
        },
        true,
      ),
      status: size ? STATUS.RUNNING : STATUS.WAITING,
    });
  };

  public stop = (advance = false) => {
    const { index, status } = this.getState();

    if (([STATUS.FINISHED, STATUS.SKIPPED] as Array<Status>).includes(status)) {
      return;
    }

    this.setState({
      ...this.getNextState({ action: ACTIONS.STOP, index: index + (advance ? 1 : 0) }),
      status: STATUS.PAUSED,
    });
  };

  public update = (state: Partial<State>) => {
    if (!hasValidKeys(state, validKeys)) {
      throw new Error(`State is not valid. Valid keys: ${validKeys.join(', ')}`);
    }

    this.setState({
      ...this.getNextState(
        {
          ...this.getState(),
          ...state,
          action: state.action ?? ACTIONS.UPDATE,
          origin: state.origin ?? null,
        },
        true,
      ),
    });
  };
}

export default function createStore(options?: StoreOptions) {
  return new Store(options);
}
